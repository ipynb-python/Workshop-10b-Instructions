# part1d.py

# The following code defines a list
# storing a set of strings

mylist = [ "I", "II", "III", "IIII", "V", "VI" ]

# create a variable named: myslice
# that selects the first 3 items from mylist

# test your code using: print(myslice)

# add code below