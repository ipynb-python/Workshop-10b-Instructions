# part2c.py

# A coder wants to write a function to add 
# two simplified roman numeral numbers that
# will work for sums up to 100:

# The basic pattern for the function is in place
# as below
#
#   def rn_add(a, b):
#       total = 0
#       # code to be added
#       # ...
#       return total

# However before they write the function they decide 
# write a test that can verify its behaviour.

# Requirement:
# It should work for any calculation that totals 100 or less.
# e.g. rn_add("I", "XX") will return 21

# ** YOU DO NOT HAVE TO WRITE THE FUNCTION CODE **

# ** YOU HAVE TO WRITE THE TESTS FOR THE FUNCTION **

# Work in file: test_rn_add.py
#
# Add test functions that can check if rn_add 
# works when given valid inputs (sum to 100 or less).

# i.e. numerals involved could include:
# I: 1:   V: 5,  X: 10,  D: 50, C: 100

# Your test code does not have to test every possibility
# but should check a suitable set of calculations

# Remember include the relevant import to load the
# function to be tested from this file

def rn_add(a, b):
   total = 0

   return total