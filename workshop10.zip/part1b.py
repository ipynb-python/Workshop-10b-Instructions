# part1b.py

# Write code to do the calculation below and 
# store the result as variable: z

# your code should make use of the variable x
# as defined below so it would work if a 
# different value is used 


#         6 + x
#  z =   -------
#         6 - x
#

# test your code with: print(z)

x = 2

# add your code below


