# part1c.py

# Create a tuple with name: mytuple
# that stores the values 12, 4, 5

# test your code using: print(mytuple)

# add code below