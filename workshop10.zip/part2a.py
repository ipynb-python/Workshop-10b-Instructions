# part2a.py

# The code below reads in a a username from
# file: user.txt

#   from pathlib import Path
#   
#   filename = "user.txt"
#   
#   username = Path(filename).read_text()
#   
#   print(f"Hello {username}")


# Ensure that the code can handle the situation
# that file "user.txt" does not exist

# In this case an exception should not occur,
# variable username should be set to: "nobody"
# and the message below should be displayed:

#    File missing, using: nobody

# followed by the result of the print statement i.e.

#    Hello nobody


# edit code below

from pathlib import Path

filename = "user.txt"

username = Path(filename).read_text()

print(f"Hello {username}")
