# part1h.py

# The following code can print a countdown
# starting from an input argument x

#    def countdown(x):
#       while x > 0:
#           print(x)
#           x = x - 1
#   
#    countdown(5)

# edit the code so:

# i. the function takes a default argument: 10

# ii. the example shows how to call the function
# to check the default argument works

# edit code below

def countdown(x):
    while x > 0:
        print(x)
        x = x - 1

countdown(5)