# part1g.py

# The following dictionary translates 
# between digits and simplified roman numerals:

mydict = {
    1: "I",
    2: "2",
    3: "III",
    4: "IIII",
    5: "V",
}

# The value for key 2 should be "II".

# Show how you can add an extra line of code
# to edit the relevant dictionary entry in mydict 
# to update this value.

# test your code with: print(mydict)

# add code below



