# part1a.py

# Look at the following example that defines
# variable:  var1  then displays info about 
# the type of object  var1  is. 

var1 = "hello"
print("var1: str")

# Edit the print lines below so they display 
# the right object types for  var2  and  var3  
# following the format from the example above.

# choose from:
# int float bool str list dict tuple

var2 = 0.6
var3 = 4

print("var2: ")
print("var3: ")