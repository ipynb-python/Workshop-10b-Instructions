# part2b.py

# The function rn_to_digit is supposed to take
# a simplified roman numeral and translate it 
# to its integer value.
#
# Requirement: 
# It should correctly translate the values below:
# I II III IIII V VI VII VIII VIIII
# 1  2  3   4   5  6  7    8    9

# e.g. rn_to_digit("III") should return the integer 3

#   def rn_to_digit(num):
#       total = 0
#       total += num.count("I")
#       total += num.count("V")
#       return total

# i. Work in file: test_rn_to_digit.py 
# Write a test function that can be used by pytest
# to check if the function works correctly for
# the stated requirements.

# Remember include the relevant import to load the
# function to be tested from this file.


# ii. Work in this file.
# At the moment the function below includes an error. 
# Edit the code to fix the function.

# edit code below

def rn_to_digit(num):
    total = 0
    total += num.count("I")
    total += num.count("V")
    return total

