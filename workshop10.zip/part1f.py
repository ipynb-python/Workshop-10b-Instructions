# part1f.py

# The following code defines a list
# storing a set of strings

mylist = [ "I", "II", "III", "IIII", "V", "VI" ]

# Write code to loop over the list items and 
# print out the number of I's in each string
# (one per line) with expected output:

#   1
#   2
#   3
#   4
#   0
#   1

# Hint.
# For a string mystr we could count the
# number of "X"s it contains using:

# mystr.count("X") 

# add code below

