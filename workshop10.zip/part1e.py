# part1e.py

# Write a function named: double_print
# that takes a single argument: msg
# The function should print this variable twice.

# e.g. 
# if we pass in the value 'banana' the
# output would be:

#   banana
#   banana

# Add code to demonstrate the function
# using argument: hello

# add code below

