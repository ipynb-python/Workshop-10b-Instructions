# part3.py

# 3a. Write a function: rn_times_ten
# that takes input argument: myval

# Requirement:
# Input argument: roman numeral (str) in range 1-100
# Output: roman numeral (str) that is ten times bigger

# Hint. You can do this by builing the output value
# from the characters in the input string using rules:
# 
# I --> X   (i.e. 1 --> 10)
# V --> D   (i.e. 5 --> 50)
# X --> C   (i.e. 10 --> 100)
# D --> L   (i.e. 50 --> 500)
# C --> M   (i.e. 100 --> 1000)

# i.e. 
# rn_times_ten("XIII") should return "CXXX"
#                13                   130


# 3b. Ensure the function includes code to
# throw and exception if a user attempts to pass 
# an input value with invalid characters


# 3c. Add test code that is able to test your function
# against the requirements.

# add code below 
# (and in test file test_rn_times_ten.py)

